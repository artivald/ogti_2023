<?php 
session_start();
include_once("phhp.php");
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ПрофТестиум</title>
    <link href="styleMain.css" rel="stylesheet">
</head>
<body>
<style type="text/css">
    p{
        color:#FFFFFF;
        font-size: 16px;
    }
</style>
  <section> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> <span></span> 

    <div class="signin">
    <div class="content">
	<div class="headerRab"><a href="index.php"><img src="logo.png" width="5%" alt="Логотип"></a></div>
    <div class="profileInfo">
	<?php 
if (isset($_SESSION['idUser'])) 
{
    $idUser = $_SESSION['idUser'];
    $users_file = 'users.txt';
    $users = file($users_file);
    echo "<p class=\"profile\">Профиль</p>";
    foreach ($users as $user) 
    {
        $row = explode("#", $user);
        if (trim($row[0]) == $_SESSION['idUser']) 
        {
            echo "<p>ID пользователя: {$row[0]}<br></p>";
            echo "<p>Фамилия: {$row[1]}<br></p>";
            echo "<p>Имя: {$row[2]}</p><br>";
            echo "<p>Отчество: {$row[3]}</p><br>";
            echo "<p>Телефон: {$row[6]}</p><br>";
            echo "<p>Почта: {$row[7]}</p><br>";
            echo "<p>Дата рождения: {$row[8]}</p><br>";
            echo "<p>Специальность: {$row[9]}</p><br>";
             echo "<td align=\"left\">
                <a href=\"index.php?action=out\" style=\"color:#00ff00; text-decoration:none; font-size:16px; font-family:Arial;\">Выход</a><br>
                </td>";
            echo "<a href=\"test.php\">Тесты</a>";
            break; 
        }
    }
}
	 ?>
    </div>
    </div>
</div>
</body>
</html>